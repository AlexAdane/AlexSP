#include<stdio.h>
#include<conio.h>
#include<dos.h>
#include<stdlib.h>
#include<process.h>

void main()
{
		 char strL[] = {'_','_','_','_','_','_','_','_','_','_','_','_'};
		 char strS[] = {'*','*','*','*','*','*','*','*','*','*','*','*'};
		int x=0;
		int y=0;
	
		printf("\n\n			");
		
		for(x=0; x<=sizeof(strL); x++){
			printf(strL + x);
			usleep(1000);
			if(12==x){
			printf("\n			");	
			y++;
			}
			if(y==1){
				y=0;x=0;
				break;
			}	
		}
		
		for(x=0; x<=sizeof(strS); x++){
			printf(strS + x);
			usleep(1000);
			if(12==x){	
			y++;
			}
			if(y==1){
				printf("\n\n			");	
			x=0;
			y++;
				break;
			}	
		}
			printf("				BAHIR DAR UNIVERSITY \n");
			printf("\n			");	
			for(x=0; x<=sizeof(strL); x++){
			printf(strL + x);
			usleep(1000);
			if(12==x){
			printf("\n			");	
			y++;
			}
			if(y==1){
				y=0;x=0;
				break;
			}	
		}
		
		for(x=0; x<=sizeof(strS); x++){
			printf(strS + x);
			usleep(1000);
			if(12==x){	
			y++;
			}
			if(y==1){
				printf("\n			");	
			x=0;
			y++;
				break;
			}	
		}	printf("\n			");	printf("			    System Programming Assignment \n");
		
		printf("			");
		
		for(x=0; x<=sizeof(strL); x++){
			printf(strL + x);
			usleep(1000);
			if(12==x){
			printf("\n			");	
			y++;
			}
			if(y==1){
				y=0;x=0;
				break;
			}	
		}
		
		for(x=0; x<=sizeof(strS); x++){
			printf(strS + x);
			usleep(1000);
			if(12==x){	
			y++;
			}
			if(y==1){
				printf("\n\n			");	
			x=0;
			y++;
				break;
			}	
		}
			printf("\n			");
		
		for(x=0; x<=sizeof(strL); x++){
			printf(strL + x);
			usleep(1000);
			if(12==x){
			printf("\n			");	
			y++;
			}
			if(y==1){
				y=0;x=0;
				break;
			}	
		}
		
		for(x=0; x<=sizeof(strS); x++){
			printf(strS + x);
			usleep(1000);
			if(12==x){	
			y++;
			}
			if(y==1){
				printf("\n\n			");	
			x=0;
			y++;
				break;
			}	
		}
		printf("\n		");
	printf("					Project Title \n");
    printf("							Folder Protector \n");
    printf("			");
		
		for(x=0; x<=sizeof(strL); x++){
			printf(strL + x);
			usleep(1000);
			if(12==x){
			printf("\n			");	
			y++;
			}
			if(y==1){
				y=0;x=0;
				break;
			}	
		}
		
		for(x=0; x<=sizeof(strS); x++){
			printf(strS + x);
			usleep(1000);
			if(12==x){	
			y++;
			}
			if(y==1){
				printf("\n\n			");	
			x=0;
			y++;
				break;
			}	
		}printf("\n			");
		    printf("		    	Prepare by Alemayehu Adane \n");
		 printf("			");   
		for(x=0; x<=sizeof(strL); x++){
			printf(strL + x);
			usleep(1000);
			if(12==x){
			printf("\n			");	
			y++;
			}
			if(y==1){
				y=0;x=0;
				break;
			}	
		}
		
		for(x=0; x<=sizeof(strS); x++){
			printf(strS + x);
			usleep(1000);
			if(12==x){	
			y++;
			}
			if(y==1){
				printf("\n\n			");	
			x=0;
			y++;
				break;
			}	
		}
		printf("\n						PRESS ENTER TO START BATCH \n\n");
		getchar();
			system("FolderProtector.bat");
 }
